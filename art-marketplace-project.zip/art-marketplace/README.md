# Online Art Gallery & Marketplace (MERN Stack Project)

This full-stack codebase provides a baseline implementation for an online art gallery built for modern college/university evaluation.

## Prerequisites
- Node.js installed locally
- MongoDB running locally (or MongoDB Atlas connection URI)

## Setup Steps

### 1. Backend Configuration
1. Navigate to the `backend/` folder.
2. Run `npm init -y` and install required dependencies:
   ```bash
   npm install express mongoose cors dotenv bcryptjs jsonwebtoken
   npm install --save-dev nodemon
   ```
3. Create a `.env` file inside `backend/` containing:
   ```env
   PORT=5000
   MONGO_URI=mongodb://localhost:27017/art_gallery
   JWT_SECRET=supersecretkey123
   ```
4. Start the backend: `npm run dev` (if configured with nodemon) or `node server.js`.

### 2. Frontend Configuration
1. Navigate to the `frontend/` folder.
2. Initialize React app or install into an existing client app:
   ```bash
   npm install react-router-dom
   ```
3. Ensure TailwindCSS is linked in your index file for rapid styling.
4. Run frontend via `npm start`.

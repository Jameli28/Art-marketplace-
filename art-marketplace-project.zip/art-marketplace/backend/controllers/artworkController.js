const Artwork = require('../models/Artwork');

exports.getAllArtworks = async (req, res) => {
  try {
    const artworks = await Artwork.find().populate('artist', 'name');
    res.json(artworks);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

exports.createArtwork = async (req, res) => {
  try {
    const { title, description, price, imageUrl, category } = req.body;
    const artwork = new Artwork({ title, description, price, imageUrl, category, artist: req.user.id });
    await artwork.save();
    res.status(201).json(artwork);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

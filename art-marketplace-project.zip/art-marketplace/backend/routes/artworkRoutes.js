const express = require('express');
const router = express.Router();
const { getAllArtworks, createArtwork } = require('../controllers/artworkController');
const auth = require('../middleware/authMiddleware');
router.get('/', getAllArtworks);
router.post('/', auth, createArtwork);
module.exports = router;

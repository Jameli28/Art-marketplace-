import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function AddArtwork() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [category, setCategory] = useState('');
  const { token } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:5000/api/artworks', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ title, description, price: Number(price), imageUrl, category })
    });
    if (res.ok) {
      navigate('/');
    } else {
      alert('Failed to add artwork');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 bg-white p-6 rounded-lg shadow-md border">
      <h2 className="text-2xl font-bold mb-6 text-center">Upload Artwork</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input type="text" placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} className="border p-2 rounded" required />
        <textarea placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} className="border p-2 rounded" required />
        <input type="number" placeholder="Price ($)" value={price} onChange={e => setPrice(e.target.value)} className="border p-2 rounded" required />
        <input type="text" placeholder="Image URL (e.g. from Unsplash)" value={imageUrl} onChange={e => setImageUrl(e.target.value)} className="border p-2 rounded" required />
        <input type="text" placeholder="Category (e.g. Painting, Digital)" value={category} onChange={e => setCategory(e.target.value)} className="border p-2 rounded" required />
        <button type="submit" className="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700">Publish Art</button>
      </form>
    </div>
  );
}

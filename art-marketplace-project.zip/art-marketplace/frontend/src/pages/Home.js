import React, { useState, useEffect } from 'react';

export default function Home() {
  const [artworks, setArtworks] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/api/artworks')
      .then(res => res.json())
      .then(data => setArtworks(data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      <h1 className="text-3xl font-bold my-6 text-center">Featured Artworks</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {artworks.map(art => (
          <div key={art._id} className="bg-white p-4 rounded-lg shadow-md border">
            <img src={art.imageUrl} alt={art.title} className="w-full h-64 object-cover rounded-md mb-4" />
            <h2 className="text-xl font-bold">{art.title}</h2>
            <p className="text-gray-500 mb-2">{art.category}</p>
            <p className="text-gray-700 text-sm mb-4 line-clamp-2">{art.description}</p>
            <div className="flex justify-between items-center">
              <span className="text-lg font-bold text-indigo-600">${art.price}</span>
              <span className="text-xs text-gray-400">By {art.artist?.name || 'Unknown'}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  return (
    <nav className="bg-white shadow-md p-4 flex justify-between items-center">
      <Link to="/" className="text-xl font-bold text-indigo-600">🎨 ArtGallery</Link>
      <div className="flex gap-4 items-center">
        <Link to="/" className="hover:text-indigo-600">Gallery</Link>
        {user ? (
          <>
            {user.role === 'artist' && <Link to="/add-art" className="bg-indigo-600 text-white px-3 py-1 rounded">Upload Art</Link>}
            <span className="text-gray-600">Hi, {user.name}</span>
            <button onClick={() => { logout(); navigate('/login'); }} className="text-red-500 hover:underline">Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" className="hover:text-indigo-600">Login</Link>
            <Link to="/register" className="bg-indigo-600 text-white px-3 py-1 rounded">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
